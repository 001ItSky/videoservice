package com.de.controller;

import com.de.entity.AjaxResult;
import com.de.util.MediaUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *  
 *  * @projectName videoservice
 *  * @title     IndexController   
 *  * @package    com.de.controller  
 *  * @description    该类的作用描述，必填  
 *  * @author IT_CREAT     
 *  * @date  2020 2020/4/11 0011 上午 0:53  
 *  * @version V1.0.0 
 *  
 */
@Controller
public class IndexController {
    @Autowired
    private MediaUtils mediaUtils;

    @GetMapping("/")
    public String indexView(){
        return "/index";
    }

    @PostMapping("/startWs")
    @ResponseBody
    public AjaxResult startWs(){
        try {
            mediaUtils.live("rtsp://127.0.0.1:8554/video","测试相机",1L);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return AjaxResult.success("开启成功");
    }
}
